<?php
// ============================================================
//  order-status.php — التحقق من حالة الطلب
//  Vue يسأل: هل الطلب رقم X مدفوع؟
//  يُستخدم في صفحة /success بعد رجوع المستخدم من Stripe
// ============================================================
require_once 'config.php';
require_once 'db.php';



$orderId     = (int)($_GET['order_id']     ?? 0);
$firebaseUid =      ($_GET['firebase_uid'] ?? '');

if (!$orderId || !$firebaseUid) {
    http_response_code(400);
    echo json_encode(['error' => 'order_id و firebase_uid مطلوبان']);
    exit;
}

try {


    // نتحقق إن الطلب يخص هذا المستخدم تحديداً
    $stmt = getDB()->prepare("
        SELECT id, product_name, amount, status, created_at
        FROM orders
        WHERE id = ? AND firebase_uid = ?
    ");
    $stmt->execute([$orderId, $firebaseUid]);
    $order = $stmt->fetch();

    if (!$order) {
        http_response_code(404);
        echo json_encode(['error' => 'الطلب غير موجود']);
        exit;
    }

    // تحويل السعر لدولار عند الإرجاع
    $order['amount_in_dollars'] = $order['amount'] / 100;

    echo json_encode(['order' => $order]);

} catch (Exception $e) {
    error_log('OrderStatus error: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'An internal error occurred. Please try again.']);
}