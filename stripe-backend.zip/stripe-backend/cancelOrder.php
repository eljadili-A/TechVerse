<?php
// ============================================================
// cancelOrder.php — إلغاء الطلب من قِبَل المستخدم
// ============================================================
// Vue يرسل: { order_id: 42, firebase_uid: "abc123" }
// PHP يرجع: { success: true } أو { error: "..." }
// ============================================================
// الشروط الأمنية:
//   1. الطلب يجب أن يكون بحالة 'pending' فقط
//   2. firebase_uid يجب أن يطابق صاحب الطلب الأصلي
// ============================================================

require_once 'config.php';
require_once 'db.php';

// ── 1. Accept POST requests only ─────────────────────────────
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit();
}

// ── 2. Read and validate the JSON body ───────────────────────
$input = json_decode(file_get_contents('php://input'), true);

$orderId     = isset($input['order_id']) ? (int)$input['order_id'] : 0;
$firebaseUid =       $input['firebase_uid'] ?? '';

if (!$orderId || !$firebaseUid) {
    http_response_code(400);
    echo json_encode(['error' => 'order_id and firebase_uid are required']);
    exit();
}

// ── 3. Attempt the cancellation ──────────────────────────────
try {
    $pdo = getDB();

    // Only cancels if:
    //   • The order belongs to this user  (firebase_uid matches)
    //   • The order is still pending      (not paid / already failed / already cancelled)
    $stmt = $pdo->prepare("
        UPDATE orders
        SET    status = 'cancelled'
        WHERE  id           = ?
          AND  firebase_uid = ?
          AND  status       = 'pending'
    ");
    $stmt->execute([$orderId, $firebaseUid]);

    if ($stmt->rowCount() === 0) {
        // Could not update — find out why so we can return a helpful message
        $check = $pdo->prepare("
            SELECT status, firebase_uid
            FROM   orders
            WHERE  id = ?
        ");
        $check->execute([$orderId]);
        $order = $check->fetch();

        if (!$order) {
            http_response_code(404);
            echo json_encode(['error' => 'Order not found']);
            exit();
        }

        if ($order['firebase_uid'] !== $firebaseUid) {
            // Do NOT reveal order ownership details to the caller
            http_response_code(403);
            echo json_encode(['error' => 'Unauthorized']);
            exit();
        }

        // Order exists and belongs to this user, but status is not 'pending'
        http_response_code(409);
        echo json_encode([
            'error'  => 'Order cannot be cancelled',
            'status' => $order['status'],
        ]);
        exit();
    }

    echo json_encode(['success' => true]);

} catch (Exception $e) {
    error_log('CancelOrder error: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'An internal error occurred. Please try again.']);
}
