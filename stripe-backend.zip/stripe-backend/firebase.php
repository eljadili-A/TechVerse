<?php
// ============================================================
// firebase.php — جلب بيانات المنتج من Firestore مباشرةً
// ============================================================
// لماذا نجلب من Firebase وليس من الفرونت؟
// لأن المستخدم يقدر يعدّل أي بيانات يرسلها الفرونت
// لكن Firebase عندنا نحن فقط، المستخدم لا يقدر يعدّل عليها
// ============================================================

require_once 'config.php';

function getProductFromFirebase(string $productId): ?array {

    // Realtime Database REST API
    $url = sprintf(
        'https://%s-default-rtdb.firebaseio.com/Products/%s.json',
        FIREBASE_PROJECT_ID,
        urlencode($productId)
    );

    // نرسل طلب GET
    $context = stream_context_create(['http' => ['method' => 'GET', 'timeout' => 10, 'ignore_errors' => true]]);
    $response = @file_get_contents($url, false, $context);

    if ($response === false) {
        return null; // المنتج غير موجود أو خطأ في الاتصال
    }

    $data = json_decode($response, true);

    // نتأكد أن البيانات موجودة فعلاً (في Realtime DB، المسار الفارغ يرجع null)
    if ($data === null || isset($data['error'])) {
        return null;
    }

    // Realtime Database يرجع البيانات كـ Array بسيط مباشرة على عكس Firestore
    // مثلا: { "name": "iPhone 15", "price": 999 }
    return [
        'name' => $data['name'] ?? 'Unknown',
        'price' => $data['price'] ?? 0,
        'stock' => $data['stock'] ?? 999
    ];
}