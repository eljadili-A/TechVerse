<?php
// ============================================================
// webhook.php — استقبال تأكيد الدفع من Stripe
// ============================================================
// Stripe يكلم هذا الملف مباشرةً بعد كل عملية دفع
// مش المستخدم — لذلك هذا هو المصدر الموثوق الوحيد
// ============================================================

require_once 'config.php';
require_once 'db.php';
require 'vendor/autoload.php';

// ── 1. نقرأ الـ raw body من Stripe ───────────────────────────
// مهم جداً: نقرأ الـ raw body قبل أي معالجة
$payload = @file_get_contents('php://input');
$sigHeader = $_SERVER['HTTP_STRIPE_SIGNATURE'] ?? '';

// ── 2. نتحقق إن الطلب فعلاً من Stripe وليس من أحد ثاني ─────
// Stripe يوقّع كل طلب بـ WEBHOOK_SECRET، إذا التوقيع غلط نرفضه
try {
    $event = \Stripe\Webhook::constructEvent(
        $payload,
        $sigHeader,
        STRIPE_WEBHOOK_SECRET
    );
} catch (\Stripe\Exception\SignatureVerificationException $e) {
    // التوقيع غلط — قد يكون شخص يحاول يزيف طلب
    http_response_code(400);
    echo json_encode(['error' => 'Invalid signature']);
    exit();
}

// ── 3. نتعامل مع نوع الحدث ────────────────────────────────────
$pdo = getDB();

switch ($event->type) {

    case 'checkout.session.completed':
        // الدفع نجح — هذا أهم حدث
        $session = $event->data->object;
        $orderId = $session->metadata->order_id ?? null;

        if ($orderId) {
            $stmt = $pdo->prepare(
                "UPDATE orders SET status = 'paid' WHERE id = ? AND stripe_session_id = ? AND status IN ('pending', 'cancelled')"
            );
            $stmt->execute([$orderId, $session->id]);
            if ($stmt->rowCount() === 0) {
                error_log("Webhook: no matching pending order for id=$orderId session={$session->id}");
            }
        }
        break;

    case 'checkout.session.expired':
        // المستخدم ما أكمل الدفع وانتهت الجلسة
        $session = $event->data->object;
        $orderId = $session->metadata->order_id ?? null;

        if ($orderId) {
            $stmt = $pdo->prepare(
                "UPDATE orders SET status = 'failed' WHERE id = ? AND stripe_session_id = ? AND status = 'pending'"
            );
            $stmt->execute([$orderId, $session->id]);
            if ($stmt->rowCount() === 0) {
                error_log("Webhook: no matching pending order for id=$orderId session={$session->id}");
            }
        }
        break;

    // يمكنك إضافة أحداث أخرى حسب الحاجة
    // case 'payment_intent.payment_failed': ...
}

// Stripe يتوقع رد 200 وإلا يعيد المحاولة
http_response_code(200);
echo json_encode(['received' => true]);