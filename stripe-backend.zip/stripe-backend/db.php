<?php
// ============================================================
// db.php — الاتصال بـ MySQL وإنشاء الجدول تلقائياً
// ============================================================

require_once 'config.php';

function getDB(): PDO
{
    // PDO هي الطريقة الآمنة للتعامل مع MySQL في PHP
    // تحمي تلقائياً من SQL Injection
    static $pdo = null;

    if ($pdo === null) {
        $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4";

        $pdo = new PDO($dsn, DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]);
    }

    return $pdo;
}

function createOrdersTable(): void
{
    $pdo = getDB();

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS orders (
            id                INT AUTO_INCREMENT PRIMARY KEY,
            firebase_uid      VARCHAR(128)        NOT NULL,
            product_id        VARCHAR(100)        NOT NULL,
            product_name      VARCHAR(255)        NOT NULL,
            amount            INT                 NOT NULL,
            currency          VARCHAR(10)         NOT NULL DEFAULT 'usd',
            stripe_session_id VARCHAR(255)        UNIQUE,
            status            ENUM('pending','paid','failed','cancelled') NOT NULL DEFAULT 'pending',
            created_at        TIMESTAMP           DEFAULT CURRENT_TIMESTAMP,
            updated_at        TIMESTAMP           DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    ");

    echo json_encode(['message' => 'Orders table created successfully']);
}