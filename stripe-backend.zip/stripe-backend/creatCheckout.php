<?php
// ============================================================
// create-checkout.php — Create a Stripe Checkout session
// ============================================================
// Vue sends: { cart_items: [{ product_id, quantity }], firebase_uid: "abc123" }
// PHP returns: { checkout_url: "https://checkout.stripe.com/..." }
// ============================================================

require_once 'config.php';
require_once 'db.php';
require_once 'firebase.php';
require 'vendor/autoload.php';

// ── 1. Accept POST requests only ─────────────────────────────
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit();
}

// ── 2. Read the JSON body sent from Vue ──────────────────────
$input = json_decode(file_get_contents('php://input'), true);

$cartItems = $input['cart_items'] ?? null;
$firebaseUid = $input['firebase_uid'] ?? null;

if (!$cartItems || !is_array($cartItems) || count($cartItems) === 0 || !$firebaseUid) {
    http_response_code(400);
    echo json_encode(['error' => 'Missing required fields: cart_items (array) and firebase_uid']);
    exit();
}

// ── 3. Fetch prices from Firebase for every item ─────────────
// Prices come from the server — never from the frontend
$lineItems = [];
$orderDetails = [];
$totalAmount = 0;

foreach ($cartItems as $item) {
    $productId = $item['product_id'] ?? null;
    $quantity = (int) ($item['quantity'] ?? 1);

    if (!$productId || $quantity < 1) {
        http_response_code(400);
        echo json_encode(['error' => 'Each cart item must have product_id and quantity >= 1']);
        exit();
    }

    $product = getProductFromFirebase($productId);

    if (!$product) {
        http_response_code(404);
        echo json_encode(['error' => "Product not found: $productId"]);
        exit();
    }

    if (!isset($product['name'], $product['price'])) {
        http_response_code(500);
        echo json_encode(['error' => "Invalid product data in Firebase: $productId"]);
        exit();
    }

    if (isset($product['stock']) && $product['stock'] < $quantity) {
        http_response_code(400);
        echo json_encode(['error' => "Not enough stock for: {$product['name']}"]);
        exit();
    }

    $unitAmount = (int) $product['price'] * 100; // Stripe expects price in cents

    $lineItems[] = [
        'price_data' => [
            'currency' => 'usd',
            'unit_amount' => $unitAmount,
            'product_data' => ['name' => $product['name']],
        ],
        'quantity' => $quantity,
    ];

    $orderDetails[] = [
        'product_id' => $productId,
        'product_name' => $product['name'],
        'quantity' => $quantity,
        'unit_amount' => $unitAmount,
    ];

    $totalAmount += $unitAmount * $quantity;
}

// ── 4. Save order + create Stripe session inside a transaction ──
try {
    $pdo = getDB();
    $pdo->beginTransaction();

    // ── Check if there is an existing 'pending' order for this user to reuse the ID ──
    $stmt = $pdo->prepare("SELECT id FROM orders WHERE firebase_uid = ? AND status = 'pending' LIMIT 1");
    $stmt->execute([$firebaseUid]);
    $existingOrder = $stmt->fetch();

    $cartSummary = implode(', ', array_map(
        fn($d) => "{$d['product_name']} x{$d['quantity']}",
        $orderDetails
    ));

    if ($existingOrder) {
        // Reuse existing pending order ID
        $orderId = $existingOrder['id'];
        $stmt = $pdo->prepare("
            UPDATE orders 
            SET    product_id = :pid, 
                   product_name = :pname, 
                   amount = :amount, 
                   currency = :currency,
                   stripe_session_id = NULL
            WHERE  id = :id
        ");
        $stmt->execute([
            ':pid'      => implode(',', array_column($orderDetails, 'product_id')),
            ':pname'    => $cartSummary,
            ':amount'   => $totalAmount,
            ':currency' => 'usd',
            ':id'       => $orderId
        ]);
    } else {
        // Create a new order
        $stmt = $pdo->prepare("
            INSERT INTO orders (firebase_uid, product_id, product_name, amount, currency, status)
            VALUES (:uid, :pid, :pname, :amount, :currency, 'pending')
        ");

        $stmt->execute([
            ':uid'      => $firebaseUid,
            ':pid'      => implode(',', array_column($orderDetails, 'product_id')),
            ':pname'    => $cartSummary,
            ':amount'   => $totalAmount,
            ':currency' => 'usd',
        ]);
        $orderId = $pdo->lastInsertId();
    }

    // ── 5. Create a Stripe Checkout Session ──────────────────────
    \Stripe\Stripe::setApiKey(STRIPE_SECRET_KEY);

    $session = \Stripe\Checkout\Session::create([
        'payment_method_types' => ['card'],
        'line_items' => $lineItems,
        'mode' => 'payment',
        'expires_at' => time() + (30 * 60), // Expires in 30 minutes
        'metadata' => [
            'order_id' => $orderId,
            'firebase_uid' => $firebaseUid,
        ],
        'success_url' => SUCCESS_URL . '?order_id=' . $orderId,
        'cancel_url' => CANCEL_URL . '?order_id=' . $orderId,
    ]);

    // Save the Stripe session ID to the order row
    $pdo->prepare("UPDATE orders SET stripe_session_id = ? WHERE id = ?")
        ->execute([$session->id, $orderId]);

    $pdo->commit();

    echo json_encode([
        'checkout_url' => $session->url,
        'order_id' => $orderId,
    ]);

} catch (Exception $e) {
    if (isset($pdo) && $pdo->inTransaction()) {
        $pdo->rollBack();
    }
    error_log('Checkout error: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'An internal error occurred. Please try again.']);
}
