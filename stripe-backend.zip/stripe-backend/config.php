<?php

require_once __DIR__ . '/vendor/autoload.php';

$dotenv = Dotenv\Dotenv::createImmutable(__DIR__);
$dotenv->load();

define('STRIPE_SECRET_KEY',    $_ENV['STRIPE_SECRET_KEY']);
define('STRIPE_PUBLIC_KEY',    $_ENV['STRIPE_PUBLIC_KEY']);
define('STRIPE_WEBHOOK_SECRET', $_ENV['STRIPE_WEBHOOK_SECRET']);

define('FIREBASE_PROJECT_ID',  $_ENV['FIREBASE_PROJECT_ID']);
define('FIREBASE_API_KEY',     $_ENV['FIREBASE_API_KEY']);

define('DB_HOST', $_ENV['DB_HOST']);
define('DB_NAME', $_ENV['DB_NAME']);
define('DB_USER', $_ENV['DB_USER']);
define('DB_PASS', $_ENV['DB_PASS'] ?? '');

define('SUCCESS_URL', $_ENV['SUCCESS_URL']);
define('CANCEL_URL',  $_ENV['CANCEL_URL']);
define('FRONTEND_ORIGIN', $_ENV['FRONTEND_ORIGIN']);

// إعدادات CORS — تسمح لـ Vue يكلم الـ PHP
header('Access-Control-Allow-Origin: ' . FRONTEND_ORIGIN);
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Content-Type: application/json');

// إذا الطلب OPTIONS (preflight من المتصفح) نرد عليه وننتهي
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}